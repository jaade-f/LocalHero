package com.example.localhero.network

import com.example.localhero.model.*
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    @POST("login")
    suspend fun login(@Body body: LoginRequest): Response<LoginResponse>

    @POST("usuarios")
    suspend fun register(@Body body: RegisterRequest): Response<Map<String, Any>>


    @GET("usuarios/{id}")
    suspend fun getUsuario(@Path("id") id: Int): Response<Usuario>

    @PUT("usuarios/{id}")
    suspend fun updatePerfil(
        @Path("id") id: Int,
        @Body body: UpdatePerfilRequest
    ): Response<Map<String, Any>>


    @GET("tiendas")
    suspend fun getTiendas(): Response<List<Tienda>>

    @GET("tiendas/{id}")
    suspend fun getTienda(@Path("id") id: Int): Response<Tienda>

    @GET("tiendas/categoria/{id_categoria}")
    suspend fun getTiendasByCategoria(@Path("id_categoria") idCategoria: Int): Response<List<Tienda>>

    @GET("tiendas/propietario/{id_usuario}")
    suspend fun getTiendaPropietario(@Path("id_usuario") idUsuario: Int): Response<Tienda>

    @POST("tiendas")
    suspend fun crearTienda(@Body body: CrearTiendaRequest): Response<Map<String, Any>>


    @GET("productos/tienda/{id_tienda}")
    suspend fun getProductosByTienda(
        @Path("id_tienda") idTienda: Int,
        @Query("todos") todos: Int = 0 ): Response<List<Producto>>

    @POST("productos")
    suspend fun crearProducto(@Body body: CrearProductoRequest): Response<Map<String, Any>>

    @PUT("productos/{id}")
    suspend fun editarProducto(
        @Path("id") id: Int,
        @Body body: EditarProductoRequest
    ): Response<Map<String, Any>>

    @DELETE("productos/{id}")
    suspend fun eliminarProducto(@Path("id") id: Int): Response<Map<String, Any>>


    @GET("categorias")
    suspend fun getCategorias(): Response<List<Categoria>>


    @GET("pedidos/{id_usuario}")
    suspend fun getPedidos(@Path("id_usuario") idUsuario: Int): Response<List<Pedido>>

    @GET("pedidos/tienda/{id_tienda}")
    suspend fun getPedidosTienda(@Path("id_tienda") idTienda: Int): Response<List<PedidoPropietario>>


    @PUT("salvados/{id_salvado}/confirmar")
    suspend fun confirmarRecogida(@Path("id_salvado") idSalvado: Int): Response<Map<String, Any>>


    @POST("salvar")
    suspend fun salvarProducto(@Body body: SalvarRequest): Response<SalvarResponse>
}
