package com.example.localhero.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.localhero.model.*
import com.example.localhero.network.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PropietarioViewModel(application: Application) : AndroidViewModel(application) {

    private val api by lazy { RetrofitClient.api }


    private val _tiendaPropia = MutableStateFlow<UiState<Tienda>>(UiState.Idle)
    val tiendaPropia: StateFlow<UiState<Tienda>> = _tiendaPropia.asStateFlow()

    fun resetTiendaPropia() { _tiendaPropia.value = UiState.Idle }

    fun loadTiendaPropia(idUsuario: Int) {
        viewModelScope.launch {
            _tiendaPropia.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) { api.getTiendaPropietario(idUsuario) }
                _tiendaPropia.value = when {
                    r.isSuccessful && r.body() != null -> UiState.Success(r.body()!!)
                    r.code() == 404                    -> UiState.Error("SIN_TIENDA")
                    else                               -> UiState.Error("Error ${r.code()}")
                }
            } catch (e: Exception) {
                _tiendaPropia.value = UiState.Error("No connection to server")
            }
        }
    }


    private val _crearTiendaState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val crearTiendaState: StateFlow<UiState<String>> = _crearTiendaState.asStateFlow()

    fun crearTienda(
        nombre: String, descripcion: String, direccion: String,
        ciudad: String, codigoPostal: String, telefono: String,
        horario: String, idPropietario: Int
    ) {
        viewModelScope.launch {
            _crearTiendaState.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) {
                    api.crearTienda(
                        CrearTiendaRequest(
                            nombre_tienda    = nombre,
                            descripcion      = descripcion,
                            direccion_tienda = direccion,
                            ciudad           = ciudad,
                            codigo_postal    = codigoPostal,
                            telefono         = telefono,
                            horario          = horario,
                            propietario_id   = idPropietario
                        )
                    )
                }
                if (r.isSuccessful) {
                    _crearTiendaState.value = UiState.Success("Store created successfully")
                    loadTiendaPropia(idPropietario)   // refresh store state
                } else {
                    val err = withContext(Dispatchers.IO) { r.errorBody()?.string() ?: "" }
                    _crearTiendaState.value = UiState.Error(
                        if (err.contains("registrada", ignoreCase = true))
                            "You already have a registered store"
                        else "Error ${r.code()}"
                    )
                }
            } catch (e: Exception) {
                _crearTiendaState.value = UiState.Error("No connection to server")
            }
        }
    }

    fun resetCrearTiendaState() { _crearTiendaState.value = UiState.Idle }


    private val _productos = MutableStateFlow<UiState<List<Producto>>>(UiState.Idle)
    val productos: StateFlow<UiState<List<Producto>>> = _productos.asStateFlow()

    fun loadProductos(idTienda: Int) {
        viewModelScope.launch {
            _productos.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) {
                    api.getProductosByTienda(idTienda, todos = 1)
                }
                _productos.value = if (r.isSuccessful)
                    UiState.Success(r.body() ?: emptyList())
                else UiState.Error("Error ${r.code()}")
            } catch (e: Exception) {
                _productos.value = UiState.Error("No connection to server")
            }
        }
    }

    private val _crearProductoState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val crearProductoState: StateFlow<UiState<String>> = _crearProductoState.asStateFlow()

    fun crearProducto(
        idTienda: Int, nombre: String, descripcion: String,
        pesoKg: Double, fechaCaducidad: String?, disponible: Int
    ) {
        viewModelScope.launch {
            _crearProductoState.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) {
                    api.crearProducto(
                        CrearProductoRequest(
                            tienda_id       = idTienda,
                            nombre          = nombre,
                            descripcion     = descripcion,
                            imagen_producto = null,     // image upload not yet implemented
                            peso_kg         = pesoKg,
                            fecha_caducidad = fechaCaducidad?.ifBlank { null },
                            disponible      = disponible
                        )
                    )
                }
                if (r.isSuccessful) {
                    _crearProductoState.value = UiState.Success("Product created successfully")
                    loadProductos(idTienda)
                } else {
                    _crearProductoState.value = UiState.Error("Error ${r.code()}")
                }
            } catch (e: Exception) {
                _crearProductoState.value = UiState.Error("No connection to server")
            }
        }
    }

    fun resetCrearProductoState() { _crearProductoState.value = UiState.Idle }


    private val _editarProductoState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val editarProductoState: StateFlow<UiState<String>> = _editarProductoState.asStateFlow()

    fun editarProducto(
        idProducto: Int, idTienda: Int, nombre: String, descripcion: String,
        pesoKg: Double, disponible: Int, fechaCaducidad: String?
    ) {
        viewModelScope.launch {
            _editarProductoState.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) {
                    api.editarProducto(
                        idProducto,
                        EditarProductoRequest(
                            nombre          = nombre,
                            descripcion     = descripcion,
                            peso_kg         = pesoKg,
                            disponible      = disponible,
                            fecha_caducidad = fechaCaducidad?.ifBlank { null }
                        )
                    )
                }
                if (r.isSuccessful) {
                    _editarProductoState.value = UiState.Success("Product updated successfully")
                    loadProductos(idTienda)
                } else {
                    _editarProductoState.value = UiState.Error("Error ${r.code()}")
                }
            } catch (e: Exception) {
                _editarProductoState.value = UiState.Error("No connection to server")
            }
        }
    }

    fun resetEditarProductoState() { _editarProductoState.value = UiState.Idle }


    private val _eliminarProductoState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val eliminarProductoState: StateFlow<UiState<String>> = _eliminarProductoState.asStateFlow()

    fun eliminarProducto(idProducto: Int, idTienda: Int) {
        viewModelScope.launch {
            _eliminarProductoState.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) { api.eliminarProducto(idProducto) }
                if (r.isSuccessful) {
                    _eliminarProductoState.value = UiState.Success("Product deleted")
                    loadProductos(idTienda)
                } else {
                    _eliminarProductoState.value = UiState.Error("Error ${r.code()}")
                }
            } catch (e: Exception) {
                _eliminarProductoState.value = UiState.Error("No connection to server")
            }
        }
    }

    fun resetEliminarProductoState() { _eliminarProductoState.value = UiState.Idle }

    fun toggleDisponibilidad(producto: Producto, idTienda: Int) {
        val nuevaDisp = if (producto.disponible == 1) 0 else 1
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    api.editarProducto(
                        producto.id_producto,
                        EditarProductoRequest(null, null, null, nuevaDisp, null)
                    )
                }
                loadProductos(idTienda)
            } catch (_: Exception) {  }
        }
    }


    private val _pedidosTienda = MutableStateFlow<UiState<List<PedidoPropietario>>>(UiState.Idle)
    val pedidosTienda: StateFlow<UiState<List<PedidoPropietario>>> = _pedidosTienda.asStateFlow()

    fun loadPedidosTienda(idTienda: Int) {
        viewModelScope.launch {
            _pedidosTienda.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) { api.getPedidosTienda(idTienda) }
                _pedidosTienda.value = if (r.isSuccessful)
                    UiState.Success(r.body() ?: emptyList())
                else UiState.Error("Error ${r.code()}")
            } catch (e: Exception) {
                _pedidosTienda.value = UiState.Error("No connection to server")
            }
        }
    }


    private val _confirmarState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val confirmarState: StateFlow<UiState<String>> = _confirmarState.asStateFlow()

    fun confirmarRecogida(idSalvado: Int, idTienda: Int) {
        viewModelScope.launch {
            try {
                val r = withContext(Dispatchers.IO) { api.confirmarRecogida(idSalvado) }
                if (r.isSuccessful) {
                    _confirmarState.value = UiState.Success("Pickup confirmed")
                    loadPedidosTienda(idTienda)     // refresh orders after confirmation
                }
            } catch (_: Exception) { /* silent fail */ }
        }
    }

    fun resetConfirmarState() { _confirmarState.value = UiState.Idle }
}
