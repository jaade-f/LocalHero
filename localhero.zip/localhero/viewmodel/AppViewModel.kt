package com.example.localhero.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.localhero.model.*
import com.example.localhero.network.RetrofitClient
import com.example.localhero.session.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Generic UI state sealed class used across the whole app
sealed class UiState<out T> {
    object Idle    : UiState<Nothing>()
    object Loading : UiState<Nothing>()
    data class Success<T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
}

/**
 * Main application ViewModel.
 * Handles session management, authentication, and all user-facing API calls.
 * Owner-specific calls are handled by [PropietarioViewModel].
 */
class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val api by lazy { RetrofitClient.api }

    val sessionManager = SessionManager(application.applicationContext)

    // ─── Session ──────────────────────────────────────────────────────────────

    private val _sesion = MutableStateFlow<UsuarioSesion?>(null)
    val sesion: StateFlow<UsuarioSesion?> = _sesion.asStateFlow()

    // Prevents showing navigation before the session is restored from SharedPreferences
    private val _sessionReady = MutableStateFlow(false)
    val sessionReady: StateFlow<Boolean> = _sessionReady.asStateFlow()

    init {
        // Restore persisted session on IO thread to avoid blocking the main thread (ANR fix)
        viewModelScope.launch(Dispatchers.IO) {
            val loggedIn = sessionManager.isLoggedIn()
            if (loggedIn) {
                val restored = UsuarioSesion(
                    id      = sessionManager.getUserId(),
                    nombre  = sessionManager.getNombre(),
                    rol     = sessionManager.getRol(),
                    usuario = sessionManager.getUsuario()
                )
                withContext(Dispatchers.Main) { _sesion.value = restored }
            }
            withContext(Dispatchers.Main) { _sessionReady.value = true }
        }
    }

    // ─── Login ────────────────────────────────────────────────────────────────

    private val _loginState = MutableStateFlow<UiState<UsuarioSesion>>(UiState.Idle)
    val loginState: StateFlow<UiState<UsuarioSesion>> = _loginState.asStateFlow()

    fun login(correo: String, password: String) {
        viewModelScope.launch {
            _loginState.value = UiState.Loading
            try {
                val response = withContext(Dispatchers.IO) {
                    api.login(LoginRequest(correo.trim(), password))
                }
                if (response.isSuccessful) {
                    val body = response.body()
                    if (body?.status == "success" && body.usuario != null) {
                        val u = body.usuario
                        withContext(Dispatchers.IO) {
                            sessionManager.saveSession(u.id, u.nombre, u.rol, u.usuario)
                        }
                        _sesion.value     = u
                        _loginState.value = UiState.Success(u)
                    } else {
                        _loginState.value = UiState.Error("Credenciales incorrectas")
                    }
                } else {
                    _loginState.value = UiState.Error(
                        when (response.code()) {
                            401  -> "Contraseña incorrecta"
                            404  -> "Usuario no encontrado"
                            else -> "Error ${response.code()}"
                        }
                    )
                }
            } catch (e: Exception) {
                _loginState.value = UiState.Error("Sin conexión con el servidor")
            }
        }
    }

    fun resetLoginState() { _loginState.value = UiState.Idle }

    // ─── Registration ─────────────────────────────────────────────────────────

    private val _registerState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val registerState: StateFlow<UiState<String>> = _registerState.asStateFlow()


    fun register(
        usuario: String,
        nombre: String,
        apellido: String,
        correo: String,
        password: String,
        telefono: String,
        direccion: String,
        rol: String = "usuario"
    ) {
        viewModelScope.launch {
            _registerState.value = UiState.Loading
            try {
                val response = withContext(Dispatchers.IO) {
                    api.register(
                        RegisterRequest(
                            usuario = usuario.trim(),
                            nombre = nombre.trim(),
                            apellido = apellido.trim(),
                            correo = correo.trim(),
                            password = password,
                            telefono = telefono.trim(),
                            direccion = direccion.trim(),
                            rol = rol
                        )
                    )
                }
                _registerState.value = if (response.isSuccessful)
                    UiState.Success("Cuenta creada correctamente")
                else {
                    val err = withContext(Dispatchers.IO) { response.errorBody()?.string() ?: "" }
                    UiState.Error(
                        if (err.contains("existen", ignoreCase = true))
                            "El usuario o correo ya están en uso"
                        else "Error ${response.code()}"
                    )
                }
            } catch (e: Exception) {
                _registerState.value = UiState.Error("Sin conexión con el servidor")
            }
        }
    }

    fun resetRegisterState() { _registerState.value = UiState.Idle }


    fun logout() {
        viewModelScope.launch(Dispatchers.IO) {
            sessionManager.clearSession()
            withContext(Dispatchers.Main) {
                _sesion.value           = null
                _loginState.value       = UiState.Idle
                _registerState.value    = UiState.Idle
                _cart.value             = emptyList()
                _tiendas.value          = UiState.Idle
                _productos.value        = UiState.Idle
                _perfil.value           = UiState.Idle
                _pedidos.value          = UiState.Idle
                _categorias.value       = UiState.Idle
                _tiendasCategoria.value = UiState.Idle
            }
        }
    }

    private val _tiendas = MutableStateFlow<UiState<List<Tienda>>>(UiState.Idle)
    val tiendas: StateFlow<UiState<List<Tienda>>> = _tiendas.asStateFlow()

    fun loadTiendas() {
        viewModelScope.launch {
            _tiendas.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) { api.getTiendas() }
                _tiendas.value = if (r.isSuccessful)
                    UiState.Success(r.body() ?: emptyList())
                else UiState.Error("Error ${r.code()}")
            } catch (e: Exception) {
                _tiendas.value = UiState.Error("Sin conexión con el servidor")
            }
        }
    }

    private val _tiendaDetalle = MutableStateFlow<UiState<Tienda>>(UiState.Idle)
    val tiendaDetalle: StateFlow<UiState<Tienda>> = _tiendaDetalle.asStateFlow()

    fun loadTienda(id: Int) {
        viewModelScope.launch {
            _tiendaDetalle.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) { api.getTienda(id) }
                _tiendaDetalle.value = if (r.isSuccessful && r.body() != null)
                    UiState.Success(r.body()!!)
                else UiState.Error("Error ${r.code()}")
            } catch (e: Exception) {
                _tiendaDetalle.value = UiState.Error("Sin conexión con el servidor")
            }
        }
    }

    private val _tiendasCategoria = MutableStateFlow<UiState<List<Tienda>>>(UiState.Idle)
    val tiendasCategoria: StateFlow<UiState<List<Tienda>>> = _tiendasCategoria.asStateFlow()

    fun loadTiendasByCategoria(idCategoria: Int) {
        viewModelScope.launch {
            _tiendasCategoria.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) { api.getTiendasByCategoria(idCategoria) }
                _tiendasCategoria.value = if (r.isSuccessful)
                    UiState.Success(r.body() ?: emptyList())
                else UiState.Error("Error ${r.code()}")
            } catch (e: Exception) {
                _tiendasCategoria.value = UiState.Error("Sin conexión con el servidor")
            }
        }
    }

    fun resetTiendasCategoria() { _tiendasCategoria.value = UiState.Idle }


    private val _categorias = MutableStateFlow<UiState<List<Categoria>>>(UiState.Idle)
    val categorias: StateFlow<UiState<List<Categoria>>> = _categorias.asStateFlow()

    fun loadCategorias() {
        viewModelScope.launch {
            _categorias.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) { api.getCategorias() }
                _categorias.value = if (r.isSuccessful)
                    UiState.Success(r.body() ?: emptyList())
                else UiState.Error("Error ${r.code()}")
            } catch (e: Exception) {
                _categorias.value = UiState.Error("Sin conexión con el servidor")
            }
        }
    }

    private val _productos = MutableStateFlow<UiState<List<Producto>>>(UiState.Idle)
    val productos: StateFlow<UiState<List<Producto>>> = _productos.asStateFlow()

    /** Loads only available products for users (todos=0). */
    fun loadProductos(idTienda: Int) {
        viewModelScope.launch {
            _productos.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) { api.getProductosByTienda(idTienda, todos = 0) }
                _productos.value = if (r.isSuccessful)
                    UiState.Success(r.body() ?: emptyList())
                else UiState.Error("Error ${r.code()}")
            } catch (e: Exception) {
                _productos.value = UiState.Error("Sin conexión con el servidor")
            }
        }
    }


    private val _perfil = MutableStateFlow<UiState<Usuario>>(UiState.Idle)
    val perfil: StateFlow<UiState<Usuario>> = _perfil.asStateFlow()

    fun loadPerfil(id: Int) {
        viewModelScope.launch {
            _perfil.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) { api.getUsuario(id) }
                _perfil.value = if (r.isSuccessful && r.body() != null)
                    UiState.Success(r.body()!!)
                else UiState.Error("Error ${r.code()}")
            } catch (e: Exception) {
                _perfil.value = UiState.Error("Sin conexión con el servidor")
            }
        }
    }


    private val _updatePerfilState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val updatePerfilState: StateFlow<UiState<String>> = _updatePerfilState.asStateFlow()

    fun updatePerfil(usuario: String, telefono: String, direccion: String) {
        val id = _sesion.value?.id ?: return
        viewModelScope.launch {
            _updatePerfilState.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) {
                    api.updatePerfil(
                        id,
                        UpdatePerfilRequest(
                            usuario   = usuario.ifBlank { null },
                            telefono  = telefono,
                            direccion = direccion
                        )
                    )
                }
                if (r.isSuccessful) {
                    if (usuario.isNotBlank()) {
                        val current = _sesion.value
                        if (current != null) {
                            val updated = current.copy(usuario = usuario)
                            _sesion.value = updated
                            withContext(Dispatchers.IO) {
                                sessionManager.saveSession(
                                    updated.id, updated.nombre, updated.rol, updated.usuario
                                )
                            }
                        }
                    }
                    loadPerfil(id)
                    _updatePerfilState.value = UiState.Success("Perfil actualizado correctamente")
                } else {
                    val errBody = withContext(Dispatchers.IO) { r.errorBody()?.string() ?: "" }
                    _updatePerfilState.value = UiState.Error(
                        if (errBody.contains("uso", ignoreCase = true))
                            "Ese nombre de usuario ya está en uso"
                        else "Error ${r.code()}"
                    )
                }
            } catch (e: Exception) {
                _updatePerfilState.value = UiState.Error("Sin conexión con el servidor")
            }
        }
    }

    fun resetUpdatePerfilState() { _updatePerfilState.value = UiState.Idle }

    private val _pedidos = MutableStateFlow<UiState<List<Pedido>>>(UiState.Idle)
    val pedidos: StateFlow<UiState<List<Pedido>>> = _pedidos.asStateFlow()

    fun loadPedidos(idUsuario: Int) {
        viewModelScope.launch {
            _pedidos.value = UiState.Loading
            try {
                val r = withContext(Dispatchers.IO) { api.getPedidos(idUsuario) }
                _pedidos.value = if (r.isSuccessful)
                    UiState.Success(r.body() ?: emptyList())
                else UiState.Error("Error ${r.code()}")
            } catch (e: Exception) {
                _pedidos.value = UiState.Error("Sin conexión con el servidor")
            }
        }
    }


    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    fun addToCart(producto: Producto) {
        val current = _cart.value.toMutableList()
        val idx = current.indexOfFirst { it.producto.id_producto == producto.id_producto }
        if (idx >= 0) current[idx] = current[idx].copy(cantidad = current[idx].cantidad + 1)
        else current.add(CartItem(producto = producto, cantidad = 1))
        _cart.value = current
    }

    fun removeFromCart(idProducto: Int) {
        _cart.value = _cart.value.filter { it.producto.id_producto != idProducto }
    }

    fun clearCart() { _cart.value = emptyList() }


    private val _confirmState = MutableStateFlow<UiState<String>>(UiState.Idle)
    val confirmState: StateFlow<UiState<String>> = _confirmState.asStateFlow()

    fun confirmarPedido() {
        val idUsuario = _sesion.value?.id ?: return
        val items = _cart.value
        if (items.isEmpty()) return

        viewModelScope.launch {
            _confirmState.value = UiState.Loading
            try {
                var errorMsg: String? = null
                withContext(Dispatchers.IO) {
                    for (item in items) {

                        val pesoTotal = (item.producto.peso_kg * item.cantidad).toInt()
                            .coerceAtLeast(1)
                        val r = api.salvarProducto(
                            SalvarRequest(
                                id_usuario = idUsuario,
                                id_producto = item.producto.id_producto,
                                peso = pesoTotal
                            )
                        )
                        if (!r.isSuccessful) {
                            errorMsg = "Error al salvar ${item.producto.nombre}: ${r.code()}"
                            break
                        }
                    }
                }
                if (errorMsg != null) {
                    _confirmState.value = UiState.Error(errorMsg!!)
                } else {
                    clearCart()
                    _confirmState.value = UiState.Success("¡Pedido confirmado correctamente!")
                }
            } catch (e: Exception) {
                _confirmState.value = UiState.Error("Sin conexión con el servidor")
            }
        }
    }

    fun resetConfirmState() { _confirmState.value = UiState.Idle }
}
