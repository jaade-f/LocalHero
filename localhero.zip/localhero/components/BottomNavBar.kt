package com.example.localhero.components

import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.localhero.navigation.Screen
import com.example.localhero.ui.theme.GreenPrimary
import com.example.localhero.ui.theme.TextGray
import androidx.compose.material.icons.outlined.Category


@Composable
fun BottomNavBar(navController: NavController, cartCount: Int = 0) {
    val entry   by navController.currentBackStackEntryAsState()
    val current = entry?.destination?.route

    NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {

        //Inicio
        NavigationBarItem(
            icon     = { Icon(Icons.Filled.Home, null, Modifier.size(22.dp)) },
            label    = { Text("Inicio", fontSize = 10.sp) },
            selected = current == Screen.Home.route,
            onClick  = {
                navController.navigate(Screen.Home.route) {
                    popUpTo(Screen.Home.route) { inclusive = false }
                    launchSingleTop = true
                }
            },
            colors = navColors()
        )

        //Categorías
        NavigationBarItem(
            icon     = { Icon(Icons.Outlined.Category, null, Modifier.size(22.dp)) },
            label    = { Text("Categorías", fontSize = 10.sp) },
            selected = current == Screen.Categorias.route ||
                    current?.startsWith("tiendas_categoria") == true,
            onClick  = {
                navController.navigate(Screen.Categorias.route) { launchSingleTop = true }
            },
            colors = navColors()
        )

        //Carrito
        NavigationBarItem(
            icon = {
                BadgedBox(badge = {
                    if (cartCount > 0) Badge { Text("$cartCount", fontSize = 9.sp) }
                }) {
                    Icon(Icons.Filled.ShoppingCart, null, Modifier.size(22.dp))
                }
            },
            label    = { Text("Carrito", fontSize = 10.sp) },
            selected = current == Screen.Carrito.route,
            onClick  = { navController.navigate(Screen.Carrito.route) { launchSingleTop = true } },
            colors   = navColors()
        )

        //Perfil
        NavigationBarItem(
            icon     = { Icon(Icons.Filled.Person, null, Modifier.size(22.dp)) },
            label    = { Text("Perfil", fontSize = 10.sp) },
            selected = current == Screen.Perfil.route || current == Screen.EditarPerfil.route,
            onClick  = { navController.navigate(Screen.Perfil.route) { launchSingleTop = true } },
            colors   = navColors()
        )
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor   = GreenPrimary,
    selectedTextColor   = GreenPrimary,
    unselectedIconColor = TextGray,
    unselectedTextColor = TextGray,
    indicatorColor      = Color.Transparent
)
