package com.example.localhero.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import coil.compose.SubcomposeAsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.localhero.ui.theme.GreenLight
import com.example.localhero.ui.theme.GreenPrimary


@Composable
fun ImagenConFallback(
    url: String?,
    contentDescription: String = "",
    modifier: Modifier = Modifier,
    fallbackEmoji: String = "🏪",
    contentScale: ContentScale = ContentScale.Crop
) {
    if (url.isNullOrBlank()) {
        FallbackBox(modifier = modifier, emoji = fallbackEmoji)
        return
    }

    val context = LocalContext.current
    val request = ImageRequest.Builder(context)
        .data(url)
        .crossfade(true)
        .memoryCachePolicy(CachePolicy.ENABLED)
        .diskCachePolicy(CachePolicy.ENABLED)
        .networkCachePolicy(CachePolicy.ENABLED)
        // Reintenta una vez si falla la red
        .build()

    SubcomposeAsyncImage(
        model            = request,
        contentDescription = contentDescription,
        contentScale     = contentScale,
        modifier         = modifier,
        loading = {
            Box(
                modifier = Modifier.fillMaxSize().background(GreenLight),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color       = GreenPrimary,
                    modifier    = Modifier.size(28.dp),
                    strokeWidth = 2.dp
                )
            }
        },
        error = {
            FallbackBox(modifier = Modifier.fillMaxSize(), emoji = fallbackEmoji)
        }
    )
}

@Composable
private fun FallbackBox(modifier: Modifier, emoji: String) {
    Box(
        modifier         = modifier.background(Color(0xFFEEEEEE)),
        contentAlignment = Alignment.Center
    ) {
        Text(text = emoji, fontSize = 36.sp)
    }
}
