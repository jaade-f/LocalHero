package com.example.localhero.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val GreenPrimary    = Color(0xFF4CAF50)
val GreenDark       = Color(0xFF2E7D32)
val GreenLight      = Color(0xFFE8F5E9)
val GreenBackground = Color(0xFFF1F8F1)
val TextDark        = Color(0xFF1B1B1B)
val TextGray        = Color(0xFF757575)
val BorderColor     = Color(0xFFE0E0E0)
val RedError        = Color(0xFFE53935)

private val LightColorScheme = lightColorScheme(
    primary          = GreenPrimary,
    onPrimary        = Color.White,
    primaryContainer = GreenLight,
    secondary        = GreenDark,
    background       = GreenBackground,
    surface          = Color.White,
    onBackground     = TextDark,
    onSurface        = TextDark,
    error            = RedError
)

@Composable
fun LocalHeroTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightColorScheme, content = content)
}
