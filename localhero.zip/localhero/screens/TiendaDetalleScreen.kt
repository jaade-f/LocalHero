package com.example.localhero.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.localhero.components.ImagenConFallback
import com.example.localhero.model.Producto
import com.example.localhero.ui.theme.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.UiState

@Composable
fun TiendaDetalleScreen(
    viewModel: AppViewModel,
    idTienda: Int,
    navController: NavController
) {
    val productosState    by viewModel.productos.collectAsState()
    val tiendaState       by viewModel.tiendaDetalle.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(idTienda) {
        viewModel.loadProductos(idTienda)
        viewModel.loadTienda(idTienda)
    }

    val tiendaNombre  = (tiendaState as? UiState.Success)?.data?.nombre_tienda ?: "Tienda"
    val tiendaImagen  = (tiendaState as? UiState.Success)?.data?.getPrimeraImagenUrl()
    val tiendaDatos   = (tiendaState as? UiState.Success)?.data

    Scaffold(
        snackbarHost   = { SnackbarHost(snackbarHostState) },
        containerColor = GreenBackground
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {

            //Header photo
            item {
                Box(modifier = Modifier.fillMaxWidth().height(210.dp)) {
                    ImagenConFallback(
                        url = tiendaImagen,
                        contentDescription = tiendaNombre,
                        fallbackEmoji = "🏪",
                        modifier = Modifier.fillMaxSize()
                    )
                    IconButton(
                        onClick  = { navController.popBackStack() },
                        modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
                    ) {
                        Surface(shape = RoundedCornerShape(50), color = Color.Black.copy(alpha = 0.45f)) {
                            Icon(
                                Icons.Filled.ArrowBack, "Volver",
                                tint     = Color.White,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }

            //Info store
            item {
                Card(
                    modifier  = Modifier.fillMaxWidth().padding(16.dp),
                    shape     = RoundedCornerShape(16.dp),
                    colors    = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(tiendaNombre, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark)
                        tiendaDatos?.let { t ->
                            Spacer(Modifier.height(3.dp))
                            Text("📍 ${t.direccion_tienda}, ${t.ciudad}", fontSize = 13.sp, color = TextGray)
                            Text("⏰ ${t.horario}", fontSize = 13.sp, color = GreenDark, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            item {
                Text(
                    "Productos disponibles",
                    fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextGray,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
                Divider(color = BorderColor, modifier = Modifier.padding(horizontal = 16.dp))
                Spacer(Modifier.height(6.dp))
            }

            //Products
            when (val state = productosState) {
                is UiState.Success -> {
                    val disponibles = state.data.filter { it.disponible == 1 }
                    if (disponibles.isEmpty()) {
                        item {
                            Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("No hay productos disponibles ahora", color = TextGray)
                            }
                        }
                    } else {
                        items(disponibles, key = { it.id_producto }) { producto ->
                            ProductoCard(
                                producto   = producto,
                                onAddToCart = {
                                    viewModel.addToCart(producto)
                                }
                            )
                            Spacer(Modifier.height(2.dp))
                        }
                    }
                }
                else -> {}
            }

            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
fun ProductoCard(producto: Producto, onAddToCart: () -> Unit) {
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            ImagenConFallback(
                url                = producto.getImagenUrl(),
                contentDescription = producto.nombre,
                fallbackEmoji      = "🥗",
                modifier           = Modifier
                    .size(90.dp)
                    .clip(RoundedCornerShape(topStart = 14.dp, bottomStart = 14.dp))
            )
            Column(
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(producto.nombre, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextDark)
                Text(producto.descripcion, fontSize = 12.sp, color = TextGray, maxLines = 2)
                Text(
                    "${producto.peso_kg} kg",
                    fontSize = 12.sp, color = GreenDark, fontWeight = FontWeight.SemiBold
                )
            }
            IconButton(onClick = onAddToCart, modifier = Modifier.padding(end = 6.dp)) {
                Icon(
                    Icons.Filled.ShoppingCart, "Añadir",
                    tint     = GreenPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}
