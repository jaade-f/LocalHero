package com.example.localhero.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.localhero.components.BottomNavBar
import com.example.localhero.ui.theme.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.UiState

@Composable
fun TiendasCategoriaScreen(
    viewModel: AppViewModel,
    navController: NavController,
    idCategoria: Int,
    nombreCategoria: String,
    onTiendaClick: (Int) -> Unit
) {
    val state by viewModel.tiendasCategoria.collectAsState()
    val cart  by viewModel.cart.collectAsState()

    LaunchedEffect(idCategoria) {
        viewModel.loadTiendasByCategoria(idCategoria)
    }

    // Limpiar al salir para no mostrar datos de otra categoría
    DisposableEffect(Unit) {
        onDispose { viewModel.resetTiendasCategoria() }
    }

    Scaffold(
        bottomBar      = { BottomNavBar(navController, cartCount = cart.size) },
        containerColor = GreenBackground,
        topBar = {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = TextDark)
                }
                Text(
                    text = nombreCategoria,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextDark,
                    modifier = Modifier.weight(1f).padding(end = 48.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    ) { padding ->
        when (val s = state) {
            is UiState.Success -> {
                if (s.data.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🔍", fontSize = 48.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Sin tiendas en esta categoría", fontSize = 15.sp, color = TextGray)
                            Text("Prueba otra categoría", fontSize = 12.sp, color = TextGray)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier       = Modifier.padding(padding),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Text(
                                "${s.data.size} tiendas con productos de «$nombreCategoria»",
                                fontSize = 12.sp, color = TextGray,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(s.data) { tienda ->
                            TiendaCard(
                                tienda  = tienda,
                                onClick = { onTiendaClick(tienda.id_tienda) }
                            )
                        }
                    }
                }
            }
            else -> {}
        }
    }
}
