package com.example.localhero.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.localhero.components.BottomNavBar
import com.example.localhero.model.Categoria
import com.example.localhero.ui.theme.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.UiState

private val categoriaColores = listOf(
    Color(0xFF63C252), Color(0xFFC0B12B), Color(0xFF096506),
    Color(0xFFA97538), Color(0xFF5A7DC4), Color(0xFF9C6ADE),
    Color(0xFF2E8B57), Color(0xFFE8944A), Color(0xFF5A7FA8)
)
private val categoriaEmojis = listOf(
    "\uD83D\uDC36", "\uD83C\uDF55\u200B", "\uD83C\uDF3A", "🥐", "\uD83D\uDC56", "\uD83C\uDF46\u200B"
)

@Composable
fun CategoriasScreen(
    viewModel: AppViewModel,
    navController: NavController,
    onCategoriaClick: (Int, String) -> Unit
) {
    val categoriasState by viewModel.categorias.collectAsState()
    val cart by viewModel.cart.collectAsState()

    LaunchedEffect(Unit) { viewModel.loadCategorias() }

    Scaffold(
        bottomBar      = { BottomNavBar(navController, cartCount = cart.size) },
        containerColor = GreenBackground
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(Modifier.height(innerPadding.calculateTopPadding()))

            Text("Categorías",
                fontSize   = 22.sp,
                fontWeight = FontWeight.Bold,
                color      = TextDark,
                modifier   = Modifier.padding(horizontal = 16.dp, vertical = 16.dp)
            )
            Text("Pulsa una categoría para ver las tiendas disponibles",
                fontSize = 13.sp,
                color    = TextGray,
                modifier = Modifier.padding(
                    start = 16.dp,
                    end = 16.dp,
                    bottom = 12.dp
                )
            )

            when (val state = categoriasState) {

                is UiState.Success -> {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {

                        itemsIndexed(state.data) { idcat, categoria ->

                            val color = categoriaColores[idcat % categoriaColores.size]
                            val emoji = categoriaEmojis[idcat % categoriaEmojis.size]

                            CategoriaCard(
                                categoria = categoria,
                                color = color,
                                emoji = emoji,
                                onClick = {
                                    onCategoriaClick(
                                        categoria.id_categoria,
                                        categoria.nombre
                                    )
                                }
                            )
                        }

                        item { Spacer(Modifier.height(8.dp)) }
                        item { Spacer(Modifier.height(8.dp)) }
                    }
                }
                else -> {}
            }
        }
    }
}

@Composable
fun CategoriaCard(
    categoria: Categoria,
    color: Color,
    emoji: String,
    onClick: () -> Unit
) {
    Card(
        modifier  = Modifier.fillMaxWidth().height(120.dp).clickable(onClick = onClick),
        shape     = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Box(
            modifier = Modifier.fillMaxSize().background(color)
        ) {
            Text(
                text     = emoji,
                fontSize = 52.sp,
                modifier = Modifier.align(Alignment.TopEnd).padding(8.dp)
            )
            Text(
                text       = categoria.nombre,
                fontSize   = 14.sp,
                fontWeight = FontWeight.Bold,
                color      = Color.White,
                textAlign  = TextAlign.Start,
                modifier   = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
            )
        }
    }
}
