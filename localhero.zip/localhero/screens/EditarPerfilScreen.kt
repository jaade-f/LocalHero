package com.example.localhero.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localhero.model.Usuario
import com.example.localhero.ui.theme.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.UiState

@Composable
fun EditarPerfilScreen(
    viewModel: AppViewModel,
    onBack: () -> Unit
) {
    val perfilState       by viewModel.perfil.collectAsState()
    val updateState       by viewModel.updatePerfilState.collectAsState()
    val snackbarHostState  = remember { SnackbarHostState() }

    val perfilActual = (perfilState as? UiState.Success)?.data

    var usuario   by rememberSaveable(perfilActual?.usuario)   { mutableStateOf(perfilActual?.usuario ?: "") }
    var telefono  by rememberSaveable(perfilActual?.telefono)  { mutableStateOf(perfilActual?.telefono ?: "") }
    var direccion by rememberSaveable(perfilActual?.direccion) { mutableStateOf(perfilActual?.direccion ?: "") }
    var localError by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(updateState) {
        when (val s = updateState) {
            is UiState.Success -> {
                snackbarHostState.showSnackbar("${s.data}")
                viewModel.resetUpdatePerfilState()
                onBack()
            }
            is UiState.Error -> {
                snackbarHostState.showSnackbar("${s.message}")
                viewModel.resetUpdatePerfilState()
            }
            else -> {}
        }
    }

    Scaffold(
        snackbarHost   = { SnackbarHost(snackbarHostState) },
        containerColor = GreenBackground,
        topBar = {
            Row(
                modifier          = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = TextDark)
                }
                Text(
                    "Editar perfil",
                    fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark,
                    modifier = Modifier.weight(1f).padding(end = 48.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Read-only info
            perfilActual?.let { u ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape    = RoundedCornerShape(14.dp),
                    colors   = CardDefaults.cardColors(containerColor = GreenLight)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Datos no editables", fontSize = 11.sp, color = TextGray, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        LabelValor("Nombre",  "${u.nombre} ${u.apellido ?: ""}")
                        LabelValor("Correo",  u.correo ?: "-")
                    }
                }
            }

            Divider(color = BorderColor)
            Text("Datos editables", fontSize = 12.sp, color = GreenDark, fontWeight = FontWeight.SemiBold)

            FormField(value = usuario,   onValueChange = { usuario = it },   label = "Nombre de usuario", keyboardType = KeyboardType.Text)
            FormField(value = telefono,  onValueChange = { telefono = it },  label = "Teléfono",          keyboardType = KeyboardType.Phone)
            FormField(value = direccion, onValueChange = { direccion = it }, label = "Dirección (calle)", keyboardType = KeyboardType.Text)

            if (localError.isNotBlank()) {
                Text(localError, color = RedError, fontSize = 13.sp,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }

            Button(
                onClick = {
                    localError = ""
                    if (usuario.isBlank()) {
                        localError = "El nombre de usuario no puede estar vacío"
                        return@Button
                    }
                    viewModel.updatePerfil(
                        usuario   = usuario.trim(),
                        telefono  = telefono.trim(),
                        direccion = direccion.trim()
                    )
                },
                modifier  = Modifier.fillMaxWidth().height(52.dp),
                shape     = RoundedCornerShape(26.dp),
                colors    = ButtonDefaults.buttonColors(containerColor = GreenDark),
                enabled   = updateState !is UiState.Loading
            ) {
                if (updateState is UiState.Loading)
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                else
                    Text("Guardar cambios", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            }
        }
    }
}

@Composable
private fun LabelValor(label: String, valor: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text("$label: ", fontSize = 13.sp, color = TextGray)
        Text(valor, fontSize = 13.sp, color = TextDark, fontWeight = FontWeight.Medium)
    }
}
