package com.example.localhero.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import com.example.localhero.components.ImagenConFallback
import com.example.localhero.model.Producto
import com.example.localhero.model.Tienda
import com.example.localhero.navigation.Screen
import com.example.localhero.ui.theme.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.PropietarioViewModel
import com.example.localhero.viewmodel.UiState

@Composable
fun PanelPropietarioScreen(
    appViewModel: AppViewModel,
    propietarioViewModel: PropietarioViewModel,
    navController: NavController,
    onCrearTienda: () -> Unit,
    onCrearProducto: (Int) -> Unit,
    onVerPedidos: (Int) -> Unit,
    onVerPerfil: () -> Unit,
    onLogout: () -> Unit
) {
    val sesion         by appViewModel.sesion.collectAsState()
    val tiendaState    by propietarioViewModel.tiendaPropia.collectAsState()
    val productosState by propietarioViewModel.productos.collectAsState()
    val snackbarHost   = remember { SnackbarHostState() }
    val eliminarState  by propietarioViewModel.eliminarProductoState.collectAsState()

    var productoAEliminar by remember { mutableStateOf<Producto?>(null) }

    //This ensures the panel reloads after creating a store or returning from other screens
    LaunchedEffect(Unit) {
        // Wait briefly if sesion hasn't been restored yet from SharedPreferences
        var attempts = 0
        while (appViewModel.sesion.value == null && attempts < 10) {
            kotlinx.coroutines.delay(100)
            attempts++
        }
        appViewModel.sesion.value?.id?.let { propietarioViewModel.loadTiendaPropia(it) }
    }

    //Fetch its products
    LaunchedEffect(tiendaState) {
        if (tiendaState is UiState.Success) {
            val idTienda = (tiendaState as UiState.Success<Tienda>).data.id_tienda
            propietarioViewModel.loadProductos(idTienda)
        }
    }

    LaunchedEffect(eliminarState) {
        when (val s = eliminarState) {
            is UiState.Success -> {
                snackbarHost.showSnackbar("🗑️ ${s.data}")
                propietarioViewModel.resetEliminarProductoState()
            }
            else -> {}
        }
    }

    //Deletion confirmation
    productoAEliminar?.let { prod ->
        AlertDialog(
            onDismissRequest = { productoAEliminar = null },
            title = { Text("Eliminar producto") },
            text = { Text("¿Seguro que quieres eliminar «${prod.nombre}»? Esta acción no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = {
                    val idTienda = (tiendaState as? UiState.Success<Tienda>)?.data?.id_tienda
                        ?: return@TextButton
                    propietarioViewModel.eliminarProducto(prod.id_producto, idTienda)
                    productoAEliminar = null
                }) { Text("Eliminar", color = RedError, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { productoAEliminar = null }) { Text("Cancelar") }
            }
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHost) },
        containerColor = GreenBackground
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {

            //Header
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.verticalGradient(listOf(Color(0xFF7DC87D), GreenPrimary)))
                        .padding(horizontal = 20.dp, vertical = 20.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Panel de propietario",
                                fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f)
                            )
                            Text(
                                "Hola, ${sesion?.nombre ?: "Propietario"}",
                                fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White
                            )
                        }
                        IconButton(onClick = onVerPerfil) {              // ← botón perfil
                            Icon(Icons.Filled.Person, null, tint = Color.White)
                        }
                        IconButton(onClick = onLogout) {
                            Icon(Icons.Filled.Logout, null, tint = Color.White)
                        }
                    }
                }
            }

            //Store section
            when (val state = tiendaState) {

                is UiState.Error -> {
                    if (state.message == "SIN_TIENDA") {
                        item { SinTiendaBanner(onCrearTienda = onCrearTienda) }
                    } else {
                        item {
                            Box(
                                Modifier.fillMaxWidth().padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(state.message, color = RedError)
                                    Spacer(Modifier.height(8.dp))
                                    Button(
                                        onClick = { sesion?.id?.let { propietarioViewModel.loadTiendaPropia(it) } },
                                        colors  = ButtonDefaults.buttonColors(containerColor = GreenDark)
                                    ) { Text("Reintentar") }
                                }
                            }
                        }
                    }
                }
                is UiState.Success -> {
                    val tienda = state.data

                    //Store info
                    item { TiendaInfoCard(tienda = tienda) }

                    //Product statistics
                    val prods = (productosState as? UiState.Success)?.data ?: emptyList()
                    item { EstadisticasRow(productos = prods) }

                    //Quick action buttons
                    item {
                        AccionesRapidas(
                            idTienda = tienda.id_tienda,
                            onCrearProducto = onCrearProducto,
                            onVerPedidos = onVerPedidos
                        )
                    }

                    //Products section header
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Mis productos",
                                fontSize = 17.sp, fontWeight = FontWeight.Bold,
                                color = TextDark, modifier = Modifier.weight(1f)
                            )
                            if (productosState is UiState.Loading)
                                CircularProgressIndicator(
                                    modifier    = Modifier.size(18.dp),
                                    color       = GreenPrimary,
                                    strokeWidth = 2.dp
                                )
                        }
                    }

                    //Product list
                    when (val ps = productosState) {
                        is UiState.Success -> {
                            if (ps.data.isEmpty()) {
                                //Empty state
                                item {
                                    Box(
                                        Modifier.fillMaxWidth().padding(24.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("📦", fontSize = 40.sp)
                                            Text("No tienes productos aún", color = TextGray, fontSize = 14.sp)
                                            Spacer(Modifier.height(8.dp))
                                            Button(
                                                onClick = { onCrearProducto(tienda.id_tienda) },
                                                colors  = ButtonDefaults.buttonColors(containerColor = GreenDark)
                                            ) { Text("Añadir primer producto") }
                                        }
                                    }
                                }
                            } else {
                                items(ps.data, key = { it.id_producto }) { producto ->
                                    ProductoPropietarioCard(
                                        producto   = producto,
                                        onEliminar = { productoAEliminar = producto },
                                    )
                                }
                            }
                        }
                        is UiState.Error -> {
                            item {
                                Text(ps.message, color = RedError, modifier = Modifier.padding(16.dp))
                            }
                        }
                        else -> {}
                    }
                }
                else -> {}
            }
        }
    }
}


@Composable
private fun SinTiendaBanner(onCrearTienda: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(
            modifier            = Modifier.fillMaxWidth().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🏪", fontSize = 48.sp)
            Spacer(Modifier.height(10.dp))
            Text("Aún no tienes tienda", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark)
            Spacer(Modifier.height(6.dp))
            Text(
                "Crea tu tienda para empezar a publicar productos y reducir el desperdicio alimentario.",
                fontSize = 13.sp, color = TextGray,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Button(
                onClick  = onCrearTienda,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape    = RoundedCornerShape(25.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = GreenDark)
            ) { Text("Crear mi tienda", fontWeight = FontWeight.SemiBold, color = Color.White) }
        }
    }
}

@Composable
private fun TiendaInfoCard(tienda: Tienda) {
    Card(
        modifier  = Modifier.fillMaxWidth().padding(16.dp),
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column {
            ImagenConFallback(
                url = tienda.getPrimeraImagenUrl(),
                fallbackEmoji = "🏪",
                modifier = Modifier
                    .fillMaxWidth().height(160.dp)
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            )
            Column(modifier = Modifier.padding(14.dp)) {
                Text(tienda.nombre_tienda, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark)
                Spacer(Modifier.height(3.dp))
                Text("📍 ${tienda.direccion_tienda}, ${tienda.ciudad}", fontSize = 13.sp, color = TextGray)
                Text("⏰ ${tienda.horario}", fontSize = 13.sp, color = GreenDark, fontWeight = FontWeight.Medium)
                tienda.telefono?.let { Text("📞 $it", fontSize = 13.sp, color = TextGray) }
            }
        }
    }
}

@Composable
private fun EstadisticasRow(productos: List<Producto>) {
    val total       = productos.size
    val disponibles = productos.count { it.estaDisponible }
    val salvados    = productos.count { !it.estaDisponible }   // products already saved by users

    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatCard("$total",       "Total",       GreenLight,           modifier = Modifier.weight(1f))
        StatCard("$disponibles", "Disponibles", Color(0xFFE8F5E9),    modifier = Modifier.weight(1f))
        StatCard("$salvados",    "Salvados",    Color(0xFFFFF9C4),    modifier = Modifier.weight(1f))
    }
}

@Composable
private fun StatCard(valor: String, label: String, bg: Color, modifier: Modifier) {
    Card(
        modifier  = modifier,
        shape     = RoundedCornerShape(14.dp),
        colors    = CardDefaults.cardColors(containerColor = bg),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(
            modifier            = Modifier.padding(12.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(valor, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextDark)
            Text(label, fontSize = 15.sp, color = TextGray)
        }
    }
}

@Composable
private fun AccionesRapidas(
    idTienda: Int,
    onCrearProducto: (Int) -> Unit,
    onVerPedidos: (Int) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Button(
            onClick  = { onCrearProducto(idTienda) },
            modifier = Modifier.weight(1f).height(48.dp),
            shape    = RoundedCornerShape(12.dp),
            colors   = ButtonDefaults.buttonColors(containerColor = GreenDark)
        ) {
            Icon(Icons.Filled.Add, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Añadir producto", fontSize = 13.sp)
        }
        OutlinedButton(
            onClick  = { onVerPedidos(idTienda) },
            modifier = Modifier.weight(1f).height(48.dp),
            shape    = RoundedCornerShape(12.dp),
            colors   = ButtonDefaults.outlinedButtonColors(contentColor = GreenDark)
        ) {
            Icon(Icons.Filled.Receipt, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Pedidos", fontSize = 13.sp)
        }
    }
}


@Composable
private fun ProductoPropietarioCard(
    producto: Producto,
    onEliminar: () -> Unit,
) {
    Card(
        modifier  = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        shape     = RoundedCornerShape(14.dp),
        colors    = CardDefaults.cardColors(
            containerColor = if (producto.estaDisponible) Color.White else Color(0xFFF5F5F5)
        ),
        elevation = CardDefaults.cardElevation(if (producto.estaDisponible) 2.dp else 0.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(topStart = 14.dp, bottomStart = 14.dp))
            ) {
                ImagenConFallback(
                    url           = producto.getImagenUrl(),
                    fallbackEmoji = "🥗",
                    modifier      = Modifier.fillMaxSize()
                )
                // Availability badge (top-right corner)
                Surface(
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp),
                    shape    = RoundedCornerShape(6.dp),
                    color    = if (producto.estaDisponible) GreenPrimary else Color(0xFFBDBDBD)
                ) {
                    Text(
                        if (producto.estaDisponible) "Disponible" else "Agotado",
                        fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }

            //Product name description and weight
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Text(
                    producto.nombre,
                    fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    color = if (producto.estaDisponible) TextDark else TextGray
                )
                Text(producto.descripcion, fontSize = 11.sp, color = TextGray, maxLines = 1)
                Text("${producto.peso_kg} kg", fontSize = 11.sp, color = GreenDark, fontWeight = FontWeight.Medium)
            }

            Column(modifier = Modifier.padding(end = 4.dp)) {

                IconButton(onClick = onEliminar, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.Delete, null, tint = RedError, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}
