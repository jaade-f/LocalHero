package com.example.localhero.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.localhero.components.BottomNavBar
import com.example.localhero.components.ImagenConFallback
import com.example.localhero.model.Tienda
import com.example.localhero.ui.theme.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.UiState

@Composable
fun HomeScreen(
    viewModel: AppViewModel,
    navController: NavController,
    onTiendaClick: (Int) -> Unit
) {
    var search by remember { mutableStateOf("") }
    val tiendasState by viewModel.tiendas.collectAsState()
    val cart         by viewModel.cart.collectAsState()
    val sesion       by viewModel.sesion.collectAsState()

    LaunchedEffect(Unit) { viewModel.loadTiendas() }

    Scaffold(
        bottomBar      = { BottomNavBar(navController, cartCount = cart.size) },
        containerColor = GreenBackground
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {

            // Saludo
            sesion?.let {
                Text(
                    "Hola, ${it.nombre} 👋",
                    fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 2.dp)
                )
                Text(
                    "¿Qué quieres salvar hoy?",
                    fontSize = 13.sp, color = TextGray,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)
                )
            }

            // Buscador
            OutlinedTextField(
                value         = search,
                onValueChange = { search = it },
                placeholder   = { Text("Buscar tiendas...", fontSize = 13.sp, color = TextGray) },
                leadingIcon   = { Icon(Icons.Filled.Search, null, tint = GreenPrimary) },
                modifier      = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                shape         = RoundedCornerShape(25.dp),
                singleLine    = true,
                colors        = OutlinedTextFieldDefaults.colors(
                    unfocusedBorderColor    = Color.Transparent,
                    focusedBorderColor      = GreenPrimary,
                    unfocusedContainerColor = Color.White,
                    focusedContainerColor   = Color.White
                )
            )

            Spacer(Modifier.height(4.dp))

            when (val state = tiendasState) {
                is UiState.Loading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = GreenPrimary)
                    }
                }
                is UiState.Error -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("😕", fontSize = 40.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(state.message, color = RedError, fontSize = 14.sp)
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.loadTiendas() },
                                colors  = ButtonDefaults.buttonColors(containerColor = GreenDark)
                            ) { Text("Reintentar") }
                        }
                    }
                }
                is UiState.Success -> {
                    val filtered = state.data.filter {
                        it.nombre_tienda.contains(search, ignoreCase = true) ||
                                it.ciudad.contains(search, ignoreCase = true) ||
                                it.direccion_tienda.contains(search, ignoreCase = true)
                    }
                    Text(
                        "${filtered.size} tiendas disponibles",
                        fontSize = 12.sp, color = TextGray,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                    LazyColumn(
                        contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(filtered, key = { it.id_tienda }) { tienda ->
                            TiendaCard(tienda = tienda, onClick = { onTiendaClick(tienda.id_tienda) })
                        }
                        item { Spacer(Modifier.height(8.dp)) }
                    }
                }
                else -> {}
            }
        }
    }
}

@Composable
fun TiendaCard(tienda: Tienda, onClick: () -> Unit) {
    Card(
        modifier  = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column {
            ImagenConFallback(
                url                = tienda.getPrimeraImagenUrl(),
                contentDescription = tienda.nombre_tienda,
                fallbackEmoji      = "🏪",
                modifier           = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            )
            Column(modifier = Modifier.padding(12.dp)) {
                Text(tienda.nombre_tienda, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextDark)
                Spacer(Modifier.height(3.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LocationOn, null, tint = TextGray, modifier = Modifier.size(13.dp))
                    Spacer(Modifier.width(2.dp))
                    Text("${tienda.direccion_tienda}, ${tienda.ciudad}", fontSize = 12.sp, color = TextGray)
                }
                Spacer(Modifier.height(3.dp))
                Text("⏰ ${tienda.horario}", fontSize = 12.sp, color = GreenDark, fontWeight = FontWeight.Medium)
            }
        }
    }
}
