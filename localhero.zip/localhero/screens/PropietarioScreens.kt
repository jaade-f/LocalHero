package com.example.localhero.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.localhero.components.ImagenConFallback
import com.example.localhero.model.PedidoPropietario
import com.example.localhero.screens.FormField
import com.example.localhero.screens.SectionLabel
import com.example.localhero.ui.theme.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.PropietarioViewModel
import com.example.localhero.viewmodel.UiState

@Composable
fun CrearTiendaScreen(
    appViewModel: AppViewModel,
    propietarioViewModel: PropietarioViewModel,
    onBack: () -> Unit,
    onTiendaCreada: () -> Unit
) {
    val sesion     = appViewModel.sesion.collectAsState().value
    val crearState by propietarioViewModel.crearTiendaState.collectAsState()
    val snackbar   = remember { SnackbarHostState() }

    var nombre by rememberSaveable { mutableStateOf("") }
    var descripcion by rememberSaveable { mutableStateOf("") }
    var direccion by rememberSaveable { mutableStateOf("") }
    var ciudad by rememberSaveable { mutableStateOf("") }
    var cp by rememberSaveable { mutableStateOf("") }
    var telefono by rememberSaveable { mutableStateOf("") }
    var horario by rememberSaveable { mutableStateOf("") }
    var localError by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(crearState) {
        when (val s = crearState) {
            is UiState.Success -> {
                snackbar.showSnackbar("${s.data}")
                propietarioViewModel.resetCrearTiendaState()
                onTiendaCreada()
            }
            is UiState.Error -> {
                snackbar.showSnackbar("${s.message}")
                propietarioViewModel.resetCrearTiendaState()
            }
            else -> {}
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = GreenBackground,
        topBar = { PropietarioTopBar("Crear mi tienda", onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = GreenLight)
            ) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.width(8.dp))
                    Text("Rellena los datos de tu establecimiento", fontSize = 13.sp, color = TextDark)
                }
            }

            SectionLabel("Información principal")
            FormField(nombre, { nombre = it }, "Nombre de la tienda *")
            FormField(descripcion, { descripcion = it }, "Descripción")
            FormField(horario, { horario = it }, "Horario (ej: 9:00-21:00)")

            SectionLabel("Ubicación")
            FormField(direccion, { direccion = it }, "Dirección *")
            FormField(ciudad, { ciudad = it }, "Ciudad *")
            FormField(cp, { cp = it }, "Código postal", keyboardType = KeyboardType.Number)

            SectionLabel("Contacto")
            FormField(telefono, { telefono = it }, "Teléfono", keyboardType = KeyboardType.Phone)

            if (localError.isNotBlank()) {
                Text(localError, color = RedError, fontSize = 13.sp,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }

            Button(
                onClick = {
                    localError = ""
                    when {
                        nombre.isBlank() || direccion.isBlank() || ciudad.isBlank() ->
                            localError = "Nombre, dirección y ciudad son obligatorios"
                        sesion == null -> localError = "Error de sesión"
                        else -> propietarioViewModel.crearTienda(
                            nombre, descripcion, direccion, ciudad, cp, telefono, horario, sesion.id
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape    = RoundedCornerShape(26.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = GreenDark),
                enabled  = crearState !is UiState.Loading
            ) {
                if (crearState is UiState.Loading)
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                else
                    Text("Crear tienda", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
fun CrearProductoScreen(
    propietarioViewModel: PropietarioViewModel,
    idTienda: Int,
    onBack: () -> Unit,
    onProductoCreado: () -> Unit
) {
    val crearState by propietarioViewModel.crearProductoState.collectAsState()
    val snackbar   = remember { SnackbarHostState() }

    var nombre by rememberSaveable { mutableStateOf("") }
    var descripcion by rememberSaveable { mutableStateOf("") }
    var pesoKg by rememberSaveable { mutableStateOf("") }
    var caducidad by rememberSaveable { mutableStateOf("") }
    var disponible by rememberSaveable { mutableStateOf(true) }
    var localError by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(crearState) {
        when (val s = crearState) {
            is UiState.Success -> {
                snackbar.showSnackbar("${s.data}")
                propietarioViewModel.resetCrearProductoState()
                onProductoCreado()
            }
            is UiState.Error -> {
                snackbar.showSnackbar("${s.message}")
                propietarioViewModel.resetCrearProductoState()
            }
            else -> {}
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = GreenBackground,
        topBar = { PropietarioTopBar("Nuevo producto", onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionLabel("Datos del producto")
            FormField(nombre, { nombre = it }, "Nombre del producto *")
            FormField(descripcion, { descripcion = it }, "Descripción")
            FormField(pesoKg, { pesoKg = it }, "Peso (kg) *", keyboardType = KeyboardType.Decimal)
            FormField(caducidad, { caducidad = it }, "Fecha caducidad (YYYY-MM-DD)")

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Disponible inmediatamente", fontSize = 14.sp, color = TextDark)
                        Text("El producto será visible para los usuarios", fontSize = 11.sp, color = TextGray)
                    }
                    Switch(
                        checked = disponible,
                        onCheckedChange = { disponible = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = GreenDark, checkedTrackColor = GreenPrimary)
                    )
                }
            }

            if (localError.isNotBlank()) {
                Text(localError, color = RedError, fontSize = 13.sp,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }

            Button(
                onClick = {
                    localError = ""
                    val peso = pesoKg.toDoubleOrNull()
                    when {
                        nombre.isBlank()  -> localError = "El nombre es obligatorio"
                        peso == null || peso <= 0 -> localError = "Introduce un peso válido"
                        else -> propietarioViewModel.crearProducto(
                            idTienda, nombre, descripcion, peso,
                            caducidad.ifBlank { null },
                            if (disponible) 1 else 0
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape    = RoundedCornerShape(26.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = GreenDark),
                enabled  = crearState !is UiState.Loading
            ) {
                if (crearState is UiState.Loading)
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                else
                    Text("Publicar producto", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
fun EditarProductoScreen(
    propietarioViewModel: PropietarioViewModel,
    idProducto: Int,
    idTienda: Int,
    onBack: () -> Unit,
    onProductoEditado: () -> Unit
) {
    val productosState by propietarioViewModel.productos.collectAsState()
    val editarState    by propietarioViewModel.editarProductoState.collectAsState()
    val snackbar       = remember { SnackbarHostState() }

    val productoActual = (productosState as? UiState.Success)?.data
        ?.firstOrNull { it.id_producto == idProducto }

    var nombre by rememberSaveable(productoActual?.nombre) { mutableStateOf(productoActual?.nombre ?: "") }
    var descripcion by rememberSaveable(productoActual?.descripcion) { mutableStateOf(productoActual?.descripcion ?: "") }
    var pesoKg by rememberSaveable(productoActual?.peso_kg) { mutableStateOf(productoActual?.peso_kg?.toString() ?: "") }
    var caducidad by rememberSaveable(productoActual?.fecha_caducidad) { mutableStateOf(productoActual?.fecha_caducidad ?: "") }
    var disponible by rememberSaveable(productoActual?.disponible) { mutableStateOf((productoActual?.disponible ?: 1) == 1) }
    var localError by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(editarState) {
        when (val s = editarState) {
            is UiState.Success -> {
                snackbar.showSnackbar("${s.data}")
                propietarioViewModel.resetEditarProductoState()
                onProductoEditado()
            }
            is UiState.Error -> {
                snackbar.showSnackbar("${s.message}")
                propietarioViewModel.resetEditarProductoState()
            }
            else -> {}
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = GreenBackground,
        topBar = { PropietarioTopBar("Editar producto", onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            productoActual?.let {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        ImagenConFallback(url = it.getImagenUrl(), fallbackEmoji = "🥗",
                            modifier = Modifier.size(60.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Editando: ${it.nombre}", fontSize = 13.sp,
                                fontWeight = FontWeight.Bold, color = TextDark)
                            Text("ID producto: ${it.id_producto}", fontSize = 11.sp, color = TextGray)
                        }
                    }
                }
            }

            SectionLabel("Datos del producto")
            FormField(nombre, { nombre = it }, "Nombre *")
            FormField(descripcion, { descripcion = it }, "Descripción")
            FormField(pesoKg, { pesoKg = it }, "Peso (kg) *", keyboardType = KeyboardType.Decimal)
            FormField(caducidad, { caducidad = it }, "Fecha caducidad (YYYY-MM-DD)")

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Disponible", fontSize = 14.sp, color = TextDark)
                        Text(if (disponible) "Visible para los usuarios" else "Oculto al público",
                            fontSize = 11.sp, color = TextGray)
                    }
                    Switch(
                        checked = disponible,
                        onCheckedChange = { disponible = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = GreenDark, checkedTrackColor = GreenPrimary)
                    )
                }
            }

            if (localError.isNotBlank()) {
                Text(localError, color = RedError, fontSize = 13.sp,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            }

            Button(
                onClick = {
                    localError = ""
                    val peso = pesoKg.toDoubleOrNull()
                    when {
                        nombre.isBlank() -> localError = "El nombre es obligatorio"
                        peso == null || peso <= 0 -> localError = "Introduce un peso válido"
                        else -> propietarioViewModel.editarProducto(
                            idProducto, idTienda, nombre, descripcion, peso,
                            if (disponible) 1 else 0,
                            caducidad.ifBlank { null }
                        )
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GreenDark),
                enabled = editarState !is UiState.Loading
            ) {
                if (editarState is UiState.Loading)
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                else
                    Text("Guardar cambios", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
fun PedidosTiendaScreen(
    propietarioViewModel: PropietarioViewModel,
    idTienda: Int,
    navController: NavController
) {
    val pedidosState   by propietarioViewModel.pedidosTienda.collectAsState()
    val confirmarState by propietarioViewModel.confirmarState.collectAsState()
    val snackbar       = remember { SnackbarHostState() }

    LaunchedEffect(idTienda) { propietarioViewModel.loadPedidosTienda(idTienda) }

    LaunchedEffect(confirmarState) {
        when (val s = confirmarState) {
            is UiState.Success -> { snackbar.showSnackbar("${s.data}"); propietarioViewModel.resetConfirmarState() }
            is UiState.Error   -> { snackbar.showSnackbar("${s.message}"); propietarioViewModel.resetConfirmarState() }
            else -> {}
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = GreenBackground,
        topBar = { PropietarioTopBar("Pedidos activos") { navController.popBackStack() } }
    ) { padding ->
        when (val state = pedidosState) {
            is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = GreenPrimary)
            }
            is UiState.Error -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(state.message, color = RedError)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { propietarioViewModel.loadPedidosTienda(idTienda) },
                        colors = ButtonDefaults.buttonColors(containerColor = GreenDark)) { Text("Reintentar") }
                }
            }
            is UiState.Success -> {
                if (state.data.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Spacer(Modifier.height(8.dp))
                            Text("No hay pedidos activos", fontSize = 15.sp, color = TextGray)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier            = Modifier.padding(padding),
                        contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Text("${state.data.size} pedidos pendientes de recogida",
                                fontSize = 12.sp, color = TextGray, modifier = Modifier.padding(bottom = 4.dp))
                        }
                        items(items = state.data, key = { pedido -> pedido.id_salvado }) { pedido ->
                            PedidoPropietarioCard(
                                pedido      = pedido,
                                onConfirmar = { propietarioViewModel.confirmarRecogida(pedido.id_salvado, idTienda) }
                            )
                        }
                    }
                }
            }
            else -> {}
        }
    }
}

@Composable
private fun PedidoPropietarioCard(pedido: PedidoPropietario, onConfirmar: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ImagenConFallback(url = pedido.getImagenProductoUrl(), fallbackEmoji = "🥗",
                    modifier = Modifier.size(56.dp))
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(pedido.producto_nombre, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextDark)
                    Text("${pedido.peso_salvado} kg  ·  ${pedido.fecha}", fontSize = 11.sp, color = TextGray)
                }
                Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFFFF9C4)) {
                    Text("Activo", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF795548),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                }
            }
            Divider(color = BorderColor, modifier = Modifier.padding(vertical = 8.dp))
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("👤 ${pedido.cliente_nombre}", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextDark)
                    pedido.cliente_telefono?.let { Text("📞 $it", fontSize = 12.sp, color = TextGray) }
                }
                Button(onClick = onConfirmar, shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenDark),
                    modifier = Modifier.height(36.dp)) {
                    Icon(Icons.Filled.Check, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Confirmar recogida", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun PropietarioTopBar(title: String, onBack: (() -> Unit)? = null) {
    Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, null, tint = TextDark) }
        } else { Spacer(Modifier.width(48.dp)) }
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark,
            modifier = Modifier.weight(1f).padding(end = if (onBack != null) 48.dp else 0.dp),
            textAlign = TextAlign.Center)
    }
}
