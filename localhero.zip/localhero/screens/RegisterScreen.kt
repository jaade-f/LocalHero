package com.example.localhero.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localhero.ui.theme.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.UiState

@Composable
fun RegisterScreen(
    viewModel: AppViewModel,
    onRegisterSuccess: () -> Unit,
    onGoToLogin: () -> Unit
) {
    var usuario by rememberSaveable { mutableStateOf("") }
    var nombre by rememberSaveable { mutableStateOf("") }
    var apellido by rememberSaveable { mutableStateOf("") }
    var correo by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var passConfirm by rememberSaveable { mutableStateOf("") }
    var telefono by rememberSaveable { mutableStateOf("") }
    var direccion by rememberSaveable { mutableStateOf("") }
    var passVisible by rememberSaveable { mutableStateOf(false) }
    var passConfirmVisible by rememberSaveable { mutableStateOf(false) }
    var localError by rememberSaveable { mutableStateOf("") }

    val registerState     by viewModel.registerState.collectAsState()
    val snackbarHostState  = remember { SnackbarHostState() }

    LaunchedEffect(registerState) {
        when (val s = registerState) {
            is UiState.Success -> {
                snackbarHostState.showSnackbar("${s.data}")
                viewModel.resetRegisterState()
                onRegisterSuccess()
            }
            is UiState.Error -> {
                snackbarHostState.showSnackbar("${s.message}")
                viewModel.resetRegisterState()
            }
            else -> {}
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }, containerColor = GreenBackground) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Header verde
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xFF7DC87D), GreenPrimary)))
                    .padding(horizontal = 16.dp, vertical = 20.dp)
            ) {
                IconButton(
                    onClick = onGoToLogin,
                    modifier = Modifier.align(Alignment.CenterStart)
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = Color.White)
                }
                Column(modifier = Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Crear cuenta", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Únete a LocalHero", fontSize = 13.sp, color = Color.White.copy(alpha = 0.85f))
                }
            }

            //Form
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                SectionLabel("Datos de acceso")

                FormField(
                    value = usuario, onValueChange = { usuario = it },
                    label = "Nombre de usuario",
                    keyboardType = KeyboardType.Text
                )
                FormField(
                    value = correo, onValueChange = { correo = it },
                    label = "Correo electrónico",
                    keyboardType = KeyboardType.Email
                )
                FormField(
                    value = password, onValueChange = { password = it },
                    label = "Contraseña",
                    isPassword = true,
                    passwordVisible = passVisible,
                    onTogglePassword = { passVisible = !passVisible }
                )
                FormField(
                    value = passConfirm, onValueChange = { passConfirm = it },
                    label = "Confirmar contraseña",
                    isPassword = true,
                    passwordVisible = passConfirmVisible,
                    onTogglePassword = { passConfirmVisible = !passConfirmVisible }
                )

                Spacer(Modifier.height(4.dp))
                SectionLabel("Datos personales")

                FormField(
                    value = nombre, onValueChange = { nombre = it },
                    label = "Nombre",
                    keyboardType = KeyboardType.Text
                )
                FormField(
                    value = apellido, onValueChange = { apellido = it },
                    label = "Apellido",
                    keyboardType = KeyboardType.Text
                )
                FormField(
                    value = telefono, onValueChange = { telefono = it },
                    label = "Teléfono (opcional)",
                    keyboardType = KeyboardType.Phone
                )
                FormField(
                    value = direccion, onValueChange = { direccion = it },
                    label = "Dirección (calle)",
                    keyboardType = KeyboardType.Text
                )

                localError?.let {
                    Text(it, color = RedError, fontSize = 13.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth())
                }

                Spacer(Modifier.height(4.dp))

                //Regisrer button
                Button(
                    onClick = {
                        localError = ""
                        when {
                            usuario.isBlank() || nombre.isBlank() || apellido.isBlank() ||
                                    correo.isBlank()  || password.isBlank() || direccion.isBlank() ->
                                localError = "Rellena todos los campos obligatorios"
                            password != passConfirm ->
                                localError = "Las contraseñas no coinciden"
                            password.length < 4 ->
                                localError = "La contraseña debe tener al menos 4 caracteres"
                            else -> viewModel.register(
                                usuario   = usuario,
                                nombre    = nombre,
                                apellido  = apellido,
                                correo    = correo,
                                password  = password,
                                telefono  = telefono,
                                direccion = direccion
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(26.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GreenDark),
                    enabled = registerState !is UiState.Loading
                ) {
                    if (registerState is UiState.Loading)
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                    else
                        Text("Crear cuenta", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                }

                //Link to login
                Text(
                    buildAnnotatedString {
                        append("¿Ya tienes cuenta? ")
                        withStyle(SpanStyle(color = GreenDark, fontWeight = FontWeight.Bold)) {
                            append("Inicia sesión")
                        }
                    },
                    fontSize = 14.sp, color = TextGray,
                    modifier = Modifier.fillMaxWidth().clickable { onGoToLogin() },
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        color = GreenDark, letterSpacing = 0.8.sp
    )
    Divider(color = BorderColor, thickness = 1.dp)
}
