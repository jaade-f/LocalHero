package com.example.localhero.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.localhero.components.BottomNavBar
import com.example.localhero.model.Usuario
import com.example.localhero.ui.theme.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.UiState

@Composable
fun PerfilScreen(
    viewModel: AppViewModel,
    navController: NavController,
    onPedidosClick: () -> Unit,
    onEditarClick: () -> Unit,
    onPanelPropietarioClick: () -> Unit,
    onLogout: () -> Unit
) {
    val sesion by viewModel.sesion.collectAsState()
    val perfilState by viewModel.perfil.collectAsState()
    val cart by viewModel.cart.collectAsState()

    LaunchedEffect(sesion) {
        sesion?.id?.let { viewModel.loadPerfil(it) }
    }

    Scaffold(
        bottomBar      = { BottomNavBar(navController, cartCount = cart.size) },
        containerColor = GreenBackground
    ) { padding ->
        when (val state = perfilState) {
            is UiState.Success -> {
                PerfilContent(
                    usuario = state.data,
                    modifier = Modifier.padding(padding),
                    onPedidosClick = onPedidosClick,
                    onEditarClick = onEditarClick,
                    onPanelPropietarioClick = onPanelPropietarioClick,
                    onLogout = onLogout
                )
            }
            else -> {}
        }
    }
}

@Composable
fun PerfilContent(
    usuario: Usuario,
    modifier: Modifier = Modifier,
    onPedidosClick: () -> Unit,
    onEditarClick: () -> Unit,
    onPanelPropietarioClick: () -> Unit,
    onLogout: () -> Unit
) {
    Column(
        modifier = modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier         = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color(0xFF7DC87D), GreenPrimary)))
                .padding(vertical = 28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier         = Modifier.size(84.dp).clip(CircleShape).background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    val fotoUrl = usuario.getImagenPerfilUrl()
                    if (fotoUrl != null) {
                        AsyncImage(
                            model              = fotoUrl,
                            contentDescription = "Foto de perfil",
                            contentScale       = ContentScale.Crop,
                            modifier           = Modifier.fillMaxSize()
                        )
                    } else {
                        Text("\uD83D\uDC64", fontSize = 42.sp)
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    "${usuario.nombre} ${usuario.apellido ?: ""}".trim(),
                    fontSize   = 18.sp, fontWeight = FontWeight.Bold, color = Color.White
                )
                Text(
                    "@${usuario.usuario}",
                    fontSize = 13.sp, color = Color.White.copy(alpha = 0.85f)
                )
                if (usuario.rol == "propietario") {
                    Spacer(Modifier.height(6.dp))
                    Surface(
                        shape  = RoundedCornerShape(20.dp),
                        color  = Color.White.copy(alpha = 0.25f)
                    ) {
                        Text(
                            "ropietario",
                            fontSize = 12.sp,
                            color    = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        if (usuario.rol == "propietario") {
            Button(
                onClick  = onPanelPropietarioClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .height(52.dp),
                shape  = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GreenDark)
            ) {
                Icon(Icons.Filled.Store, null, modifier = Modifier.size(20.dp), tint = Color.White)
                Spacer(Modifier.width(8.dp))
                Text(
                    "Ir al panel de propietario",
                    fontSize   = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color      = Color.White
                )
            }
            Spacer(Modifier.height(12.dp))
        }

        Card(
            modifier  = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape     = RoundedCornerShape(16.dp),
            colors    = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {

                usuario.correo?.let {
                    PerfilInfoRow(Icons.Filled.Email, "Correo", it)
                    Divider(color = BorderColor, modifier = Modifier.padding(vertical = 8.dp))
                }
                usuario.telefono?.let {
                    PerfilInfoRow(Icons.Filled.Phone, "Teléfono", it)
                    Divider(color = BorderColor, modifier = Modifier.padding(vertical = 8.dp))
                }
                usuario.direccion?.let {
                    PerfilInfoRow(Icons.Filled.Home, "Dirección", it)
                    Divider(color = BorderColor, modifier = Modifier.padding(vertical = 8.dp))
                }

                Row(
                    modifier          = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Edit, null, tint = GreenPrimary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Editar perfil", fontSize = 14.sp, color = TextDark, modifier = Modifier.weight(1f))
                    TextButton(onClick = onEditarClick) {
                        Text("Editar →", color = GreenDark, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }

                Divider(color = BorderColor, modifier = Modifier.padding(vertical = 4.dp))

                Row(
                    modifier          = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Receipt, null, tint = GreenPrimary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Mis pedidos", fontSize = 14.sp, color = TextDark, modifier = Modifier.weight(1f))
                    TextButton(onClick = onPedidosClick) {
                        Text("Ver todos →", color = GreenDark, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Card(
            modifier  = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape     = RoundedCornerShape(16.dp),
            colors    = CardDefaults.cardColors(containerColor = GreenDark),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(
                modifier            = Modifier.fillMaxWidth().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("♻️", fontSize = 36.sp)
                Spacer(Modifier.height(6.dp))
                Text(
                    "${String.format("%.1f", usuario.total_kg)} kg",
                    fontSize   = 36.sp, fontWeight = FontWeight.Bold, color = Color.White
                )
                Text(
                    "salvados del desperdicio alimentario",
                    fontSize  = 13.sp, color = Color.White.copy(alpha = 0.85f),
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        OutlinedButton(
            onClick  = onLogout,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(48.dp),
            shape    = RoundedCornerShape(24.dp),
            colors   = ButtonDefaults.outlinedButtonColors(contentColor = RedError)
        ) {
            Icon(Icons.Filled.Logout, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Cerrar sesión", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun PerfilInfoRow(icon: ImageVector, label: String, value: String) {
    Row(
        modifier          = Modifier.fillMaxWidth().padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = GreenPrimary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(label, fontSize = 11.sp, color = TextGray)
            Text(value, fontSize = 14.sp, color = TextDark)
        }
    }
}

