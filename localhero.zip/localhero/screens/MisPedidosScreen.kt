package com.example.localhero.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.localhero.model.Pedido
import com.example.localhero.ui.theme.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.UiState

@Composable
fun MisPedidosScreen(
    viewModel: AppViewModel,
    navController: NavController
) {
    val sesion       by viewModel.sesion.collectAsState()
    val pedidosState by viewModel.pedidos.collectAsState()

    LaunchedEffect(sesion) {
        sesion?.id?.let { viewModel.loadPedidos(it) }
    }

    Scaffold(
        containerColor = GreenBackground,
        topBar = {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Volver", tint = TextDark)
                }
                Text("Mis Pedidos",
                    fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextDark,
                    modifier = Modifier.weight(1f).padding(end = 48.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    ) { padding ->
        when (val state = pedidosState) {
            is UiState.Success -> {
                if (state.data.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Spacer(Modifier.height(10.dp))
                            Text("No tienes pedidos aún", fontSize = 15.sp, color = TextGray)
                            Text("Añade productos y confirma tu pedido", fontSize = 12.sp, color = TextGray)
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.padding(padding),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Text(
                                "${state.data.size} pedidos realizados",
                                fontSize = 12.sp, color = TextGray,
                                modifier = Modifier.padding(bottom = 4.dp)
                            )
                        }
                        items(state.data) { pedido -> PedidoCard(pedido = pedido) }
                    }
                }
            }
            else -> {}
        }
    }
}

@Composable
fun PedidoCard(pedido: Pedido) {
    val (estadoColor, estadoEmoji) = when (pedido.estado.lowercase()) {
        "activo"     -> Pair(GreenPrimary, "🟢")
        "completado" -> Pair(Color(0xFF1976D2), "✅")
        "cancelado"  -> Pair(RedError, "❌")
        else         -> Pair(TextGray, "⏳")
    }

    Card(
        modifier  = Modifier.fillMaxWidth(),
        shape     = RoundedCornerShape(14.dp),
        colors    = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(pedido.producto_nombre, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextDark)
                Spacer(Modifier.height(2.dp))
                Text(pedido.nombre_tienda, fontSize = 12.sp, color = TextGray)
                Text("${pedido.peso_salvado} kg  ·  ${pedido.fecha}", fontSize = 11.sp, color = TextGray)
            }
            Surface(shape = RoundedCornerShape(20.dp), color = estadoColor.copy(alpha = 0.12f)) {
                Text(
                    "$estadoEmoji ${pedido.estado}",
                    fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = estadoColor,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}
