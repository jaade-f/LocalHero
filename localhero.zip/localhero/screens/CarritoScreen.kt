package com.example.localhero.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.localhero.components.BottomNavBar
import com.example.localhero.model.CartItem
import com.example.localhero.navigation.Screen
import com.example.localhero.ui.theme.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.UiState

@Composable
fun CarritoScreen(
    viewModel: AppViewModel,
    navController: NavController
) {
    val cart by viewModel.cart.collectAsState()
    val confirmState by viewModel.confirmState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    //Confirm state of the product
    LaunchedEffect(confirmState) {
        when (val s = confirmState) {
            is UiState.Success -> {
                snackbarHostState.showSnackbar(s.data)
                viewModel.resetConfirmState()
                navController.navigate(Screen.MisPedidos.route) {
                    popUpTo(Screen.Carrito.route) { inclusive = true }
                }
            }
            is UiState.Error -> {
                snackbarHostState.showSnackbar("${s.message}")
                viewModel.resetConfirmState()
            }
            else -> {}
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar    = { BottomNavBar(navController, cartCount = cart.size) },
        containerColor = GreenBackground
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {

            Text(
                "Mi Carrito",
                fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextDark,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            )
            Divider(color = BorderColor, modifier = Modifier.padding(horizontal = 16.dp))

            if (cart.isEmpty()) {
                Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🛒", fontSize = 52.sp)
                        Spacer(Modifier.height(10.dp))
                        Text("Tu carrito está vacío", fontSize = 15.sp, color = TextGray)
                        Spacer(Modifier.height(6.dp))
                        Text("Añade productos desde las tiendas", fontSize = 12.sp, color = TextGray)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(cart, key = { it.producto.id_producto }) { item ->
                        CarritoItemCard(item = item, onRemove = { viewModel.removeFromCart(item.producto.id_producto) })
                    }
                }

                //Resumen
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = GreenLight)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Total:", fontWeight = FontWeight.SemiBold, color = TextDark, fontSize = 14.sp)
                            Text("${cart.sumOf { it.cantidad }} productos", fontSize = 12.sp, color = TextGray)
                        }
                        Text(
                            "${String.format("%.2f", cart.sumOf { it.producto.peso_kg * it.cantidad })} kg salvados",
                            fontWeight = FontWeight.Bold, color = GreenDark, fontSize = 14.sp
                        )
                    }
                }

                //Confirm
                Button(
                    onClick  = { viewModel.confirmarPedido() },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).height(52.dp),
                    shape    = RoundedCornerShape(26.dp),
                    colors   = ButtonDefaults.buttonColors(containerColor = GreenDark),
                    enabled  = confirmState !is UiState.Loading
                ) {
                    if (confirmState is UiState.Loading)
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                    else
                        Text("Confirmar pedido", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                }
            }
        }
    }
}

@Composable
fun CarritoItemCard(item: CartItem, onRemove: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(14.dp),
        colors   = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(80.dp).clip(RoundedCornerShape(topStart = 14.dp, bottomStart = 14.dp))) {
                AsyncImage(
                    model = item.producto.getImagenUrl(),
                    contentDescription = item.producto.nombre,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 10.dp)) {
                Text(item.producto.nombre, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextDark)
                Text(item.producto.descripcion, fontSize = 12.sp, color = TextGray, maxLines = 1)
                Text(
                    "Cantidad: ${item.cantidad}  ·  ${String.format("%.2f", item.producto.peso_kg * item.cantidad)} kg",
                    fontSize = 12.sp, color = GreenDark, fontWeight = FontWeight.Medium
                )
            }
            IconButton(onClick = onRemove) {
                Icon(Icons.Filled.Delete, contentDescription = "Eliminar", tint = RedError)
            }
        }
    }
}

