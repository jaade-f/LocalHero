package com.example.localhero.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localhero.R
import com.example.localhero.ui.theme.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.UiState

@Composable
fun LoginScreen(
    viewModel: AppViewModel,
    onLoginSuccess: (String) -> Unit,
    onGoToRegister: () -> Unit,
    onGoToRegisterPropietario: () -> Unit
) {
    // rememberSaveable preserves values across configuration changes (rotation)
    var correo      by rememberSaveable { mutableStateOf("") }
    var password    by rememberSaveable { mutableStateOf("") }
    var passVisible by rememberSaveable { mutableStateOf(false) }

    val loginState by viewModel.loginState.collectAsState()

    LaunchedEffect(loginState) {
        if (loginState is UiState.Success) {
            val rol = (loginState as UiState.Success).data.rol
            viewModel.resetLoginState()
            onLoginSuccess(rol)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(listOf(Color(0xFFB8E6B8), Color(0xFF7DC87D), GreenPrimary))
            ),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier         = Modifier.size(110.dp).clip(CircleShape).background(Color.White),
                    contentAlignment = Alignment.Center
                ) {Image(
                    painter = painterResource(id = R.drawable.logo),
                    contentDescription = "Logo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )}
                Spacer(Modifier.height(10.dp))
                Text("LocalHero", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        Card(
            modifier  = Modifier.fillMaxWidth(),
            shape     = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
            colors    = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(0.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 28.dp, vertical = 28.dp)) {

                Text(
                    "Iniciar sesión", fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    color = TextDark, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(20.dp))

                FormField(value = correo, onValueChange = { correo = it },
                    label = "Correo electrónico", keyboardType = KeyboardType.Email)
                Spacer(Modifier.height(12.dp))
                FormField(value = password, onValueChange = { password = it },
                    label = "Contraseña", isPassword = true,
                    passwordVisible = passVisible, onTogglePassword = { passVisible = !passVisible })

                if (loginState is UiState.Error) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        (loginState as UiState.Error).message,
                        color = RedError, fontSize = 13.sp,
                        textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(Modifier.height(22.dp))

                Button(
                    onClick = {
                        if (correo.isNotBlank() && password.isNotBlank())
                            viewModel.login(correo, password)
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape    = RoundedCornerShape(26.dp),
                    colors   = ButtonDefaults.buttonColors(containerColor = GreenDark),
                    enabled  = loginState !is UiState.Loading
                ) {
                    if (loginState is UiState.Loading)
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                    else
                        Text("Entrar", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                }

                Spacer(Modifier.height(16.dp))

                Text(
                    buildAnnotatedString {
                        append("¿No tienes cuenta? ")
                        withStyle(SpanStyle(color = GreenDark, fontWeight = FontWeight.Bold)) { append("Regístrate") }
                    },
                    fontSize = 14.sp, color = TextGray,
                    modifier = Modifier.fillMaxWidth().clickable { onGoToRegister() },
                    textAlign = TextAlign.Center
                )

                Spacer(Modifier.height(16.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape    = RoundedCornerShape(14.dp),
                    colors   = CardDefaults.cardColors(containerColor = GreenLight)
                ) {
                    Row(
                        modifier          = Modifier.fillMaxWidth().padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🏪", fontSize = 28.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("¿Tienes un establecimiento?", fontSize = 13.sp,
                                fontWeight = FontWeight.Bold, color = TextDark)
                            Text("Únete como propietario y reduce el desperdicio",
                                fontSize = 11.sp, color = TextGray)
                        }
                        TextButton(onClick = onGoToRegisterPropietario) {
                            Text("Unirse →", color = GreenDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
