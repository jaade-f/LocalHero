package com.example.localhero.session

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {

    private val prefs: SharedPreferences by lazy {
        context.applicationContext.getSharedPreferences(
            "localhero_session",
            Context.MODE_PRIVATE
        )
    }

    companion object {
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_NOMBRE = "user_nombre"
        private const val KEY_USER_ROL = "user_rol"
        private const val KEY_USER_USUARIO = "user_usuario"
        private const val KEY_IS_LOGGED = "is_logged_in"
    }

    fun saveSession(id: Int, nombre: String, rol: String, usuario: String) {
        prefs.edit()
            .putInt(KEY_USER_ID, id)
            .putString(KEY_USER_NOMBRE, nombre)
            .putString(KEY_USER_ROL, rol)
            .putString(KEY_USER_USUARIO, usuario)
            .putBoolean(KEY_IS_LOGGED, true)
            .apply()
    }

    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_IS_LOGGED, false)
    fun getUserId(): Int = prefs.getInt(KEY_USER_ID, -1)
    fun getNombre(): String = prefs.getString(KEY_USER_NOMBRE, "") ?: ""
    fun getRol(): String = prefs.getString(KEY_USER_ROL, "") ?: ""
    fun getUsuario(): String = prefs.getString(KEY_USER_USUARIO, "") ?: ""

    fun clearSession() {
        prefs.edit().clear().apply()
    }
}
