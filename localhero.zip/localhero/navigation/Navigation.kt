package com.example.localhero.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.localhero.screens.*
import com.example.localhero.viewmodel.AppViewModel
import com.example.localhero.viewmodel.PropietarioViewModel


sealed class Screen(val route: String) {

    object Login               : Screen("login")
    object Register            : Screen("register")
    object RegisterPropietario : Screen("register_propietario")

    //User screens
    object Home             : Screen("home")
    object Categorias       : Screen("categorias")
    object TiendasCategoria : Screen("tiendas_categoria/{idCategoria}/{nombreCategoria}") {
        fun createRoute(id: Int, nombre: String) =
            "tiendas_categoria/$id/${nombre.replace("/", "-")}"
    }
    object TiendaDetalle    : Screen("tienda/{idTienda}") {
        fun createRoute(id: Int) = "tienda/$id"
    }
    object Carrito          : Screen("carrito")
    object Perfil           : Screen("perfil")
    object EditarPerfil     : Screen("editar_perfil")
    object MisPedidos       : Screen("mis_pedidos")

    //Owner screens
    object PanelPropietario : Screen("propietario_panel")
    object CrearTienda      : Screen("propietario_crear_tienda")
    object CrearProducto    : Screen("propietario_crear_producto/{idTienda}") {
        fun createRoute(id: Int) = "propietario_crear_producto/$id"
    }
    object EditarProducto   : Screen("propietario_editar_producto/{idProducto}/{idTienda}") {
        fun createRoute(idProducto: Int, idTienda: Int) =
            "propietario_editar_producto/$idProducto/$idTienda"
    }
    object PedidosTienda    : Screen("propietario_pedidos/{idTienda}") {
        fun createRoute(id: Int) = "propietario_pedidos/$id"
    }
}


@Composable
fun AppNavigation(viewModel: AppViewModel) {
    val navController        = rememberNavController()
    val propietarioViewModel: PropietarioViewModel = viewModel()

    // Determine start destination based on persisted session role
    val start = when {
        !viewModel.sessionManager.isLoggedIn()              -> Screen.Login.route
        viewModel.sessionManager.getRol() == "propietario" -> Screen.PanelPropietario.route
        else                                                -> Screen.Home.route
    }

    NavHost(navController = navController, startDestination = start) {


        composable(Screen.Login.route) {
            LoginScreen(
                viewModel      = viewModel,
                // Redirect to the correct home screen based on the user's role
                onLoginSuccess = { rol ->
                    val dest = if (rol == "propietario")
                        Screen.PanelPropietario.route else Screen.Home.route
                    navController.navigate(dest) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                onGoToRegister            = { navController.navigate(Screen.Register.route) },
                onGoToRegisterPropietario = { navController.navigate(Screen.RegisterPropietario.route) }
            )
        }

        composable(Screen.Register.route) {
            RegisterScreen(
                viewModel         = viewModel,
                onRegisterSuccess = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(Screen.Register.route) { inclusive = true }
                    }
                },
                onGoToLogin = { navController.popBackStack() }
            )
        }

        composable(Screen.RegisterPropietario.route) {
            RegisterPropietarioScreen(
                viewModel         = viewModel,
                onRegisterSuccess = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(Screen.RegisterPropietario.route) { inclusive = true }
                    }
                },
                onGoToLogin = { navController.popBackStack() }
            )
        }

        //User

        composable(Screen.Home.route) {
            HomeScreen(
                viewModel     = viewModel,
                navController = navController,
                onTiendaClick = { id ->
                    navController.navigate(Screen.TiendaDetalle.createRoute(id))
                }
            )
        }

        composable(Screen.Categorias.route) {
            CategoriasScreen(
                viewModel        = viewModel,
                navController    = navController,
                onCategoriaClick = { id, nombre ->
                    navController.navigate(Screen.TiendasCategoria.createRoute(id, nombre))
                }
            )
        }

        composable(Screen.TiendasCategoria.route) { back ->
            val idCategoria     = back.arguments?.getString("idCategoria")?.toIntOrNull()
                ?: return@composable
            val nombreCategoria = back.arguments?.getString("nombreCategoria") ?: ""
            TiendasCategoriaScreen(
                viewModel       = viewModel,
                navController   = navController,
                idCategoria     = idCategoria,
                nombreCategoria = nombreCategoria,
                onTiendaClick   = { id ->
                    navController.navigate(Screen.TiendaDetalle.createRoute(id))
                }
            )
        }

        composable(Screen.TiendaDetalle.route) { back ->
            val idTienda = back.arguments?.getString("idTienda")?.toIntOrNull()
                ?: return@composable
            TiendaDetalleScreen(
                viewModel     = viewModel,
                idTienda      = idTienda,
                navController = navController
            )
        }

        composable(Screen.Carrito.route) {
            CarritoScreen(viewModel = viewModel, navController = navController)
        }

        composable(Screen.Perfil.route) {
            PerfilScreen(
                viewModel               = viewModel,
                navController           = navController,
                onPedidosClick          = { navController.navigate(Screen.MisPedidos.route) },
                onEditarClick           = { navController.navigate(Screen.EditarPerfil.route) },
                onPanelPropietarioClick = {
                    navController.navigate(Screen.PanelPropietario.route) {
                        popUpTo(Screen.Perfil.route) { inclusive = true }
                    }
                },
                onLogout                = {
                    viewModel.logout()
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.EditarPerfil.route) {
            EditarPerfilScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
        }

        composable(Screen.MisPedidos.route) {
            MisPedidosScreen(viewModel = viewModel, navController = navController)
        }

        //Owner

        composable(Screen.PanelPropietario.route) {
            PanelPropietarioScreen(
                appViewModel         = viewModel,
                propietarioViewModel = propietarioViewModel,
                navController        = navController,
                onCrearTienda        = { navController.navigate(Screen.CrearTienda.route) },
                onCrearProducto      = { idTienda ->
                    navController.navigate(Screen.CrearProducto.createRoute(idTienda))
                },

                onVerPedidos         = { idTienda ->
                    navController.navigate(Screen.PedidosTienda.createRoute(idTienda))
                },
                onVerPerfil          = { navController.navigate(Screen.Perfil.route) },  // ← añade esto
                onLogout             = {
                    viewModel.logout()
                    navController.navigate(Screen.Login.route) { popUpTo(0) { inclusive = true } }
                }
            )
        }

        composable(Screen.CrearTienda.route) {
            CrearTiendaScreen(
                appViewModel         = viewModel,
                propietarioViewModel = propietarioViewModel,
                onBack               = { navController.popBackStack() },
                onTiendaCreada       = {
                    // Replace the create-store screen with the panel to avoid going back to it
                    navController.navigate(Screen.PanelPropietario.route) {
                        popUpTo(Screen.CrearTienda.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.CrearProducto.route) { back ->
            val idTienda = back.arguments?.getString("idTienda")?.toIntOrNull()
                ?: return@composable
            CrearProductoScreen(
                propietarioViewModel = propietarioViewModel,
                idTienda             = idTienda,
                onBack               = { navController.popBackStack() },
                onProductoCreado     = { navController.popBackStack() }
            )
        }

        composable(Screen.EditarProducto.route) { back ->
            val idProducto = back.arguments?.getString("idProducto")?.toIntOrNull()
                ?: return@composable
            val idTienda   = back.arguments?.getString("idTienda")?.toIntOrNull()
                ?: return@composable
            EditarProductoScreen(
                propietarioViewModel = propietarioViewModel,
                idProducto           = idProducto,
                idTienda             = idTienda,
                onBack               = { navController.popBackStack() },
                onProductoEditado    = { navController.popBackStack() }
            )
        }

        composable(Screen.PedidosTienda.route) { back ->
            val idTienda = back.arguments?.getString("idTienda")?.toIntOrNull()
                ?: return@composable
            PedidosTiendaScreen(
                propietarioViewModel = propietarioViewModel,
                idTienda             = idTienda,
                navController        = navController
            )
        }
    }
}
