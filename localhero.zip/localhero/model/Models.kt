package com.example.localhero.model
data class LoginRequest(val correo: String, val password: String)

data class LoginResponse(val status: String, val usuario: UsuarioSesion?)

data class UsuarioSesion(
    val id: Int,
    val nombre: String,
    val rol: String,
    val usuario: String
) {
    val esPropietario get() = rol == "propietario"
    val esUsuario     get() = rol == "usuario"
}


data class RegisterRequest(
    @com.google.gson.annotations.SerializedName("usuario")  val usuario: String,
    @com.google.gson.annotations.SerializedName("nombre")   val nombre: String,
    @com.google.gson.annotations.SerializedName("apellido") val apellido: String,
    @com.google.gson.annotations.SerializedName("correo")   val correo: String,
    @com.google.gson.annotations.SerializedName("password") val password: String,
    @com.google.gson.annotations.SerializedName("telefono") val telefono: String,
    @com.google.gson.annotations.SerializedName("direccion")val direccion: String,
    @com.google.gson.annotations.SerializedName("rol")      val rol: String
)

data class UpdatePerfilRequest(
    val usuario: String?,
    val telefono: String?,
    val direccion: String?,
    val imagen_perfil: String? = null
)

data class Usuario(
    val nombre: String,
    val apellido: String?,
    val usuario: String,
    val correo: String?,
    val telefono: String?,
    val direccion: String?,
    val rol: String,
    val total_kg: Double,
    val imagen_perfil: String? = null
) {
    fun getImagenPerfilUrl(): String? =
        imagen_perfil?.let { "http://10.0.2.2:8000/static/img/$it" }
}


data class Tienda(
    val id_tienda: Int,
    val nombre_tienda: String,
    val direccion_tienda: String,
    val ciudad: String,
    val horario: String,
    val latitud: Double?,
    val longitud: Double?,
    val imagenes: String,
    val descripcion: String? = null,
    val telefono: String? = null,
    val codigo_postal: String? = null
) {
    fun getPrimeraImagenUrl(): String? {
        return try {
            val nombres = imagenes.trim()
                .removePrefix("[").removeSuffix("]")
                .split(",")
                .map { it.trim().removeSurrounding("\"").removeSurrounding("'") }
                .filter { it.isNotBlank() }
            if (nombres.isNotEmpty()) "http://10.0.2.2:8000/static/img/${nombres[0]}" else null
        } catch (e: Exception) { null }
    }
}

data class CrearTiendaRequest(
    val nombre_tienda: String,
    val descripcion: String,
    val direccion_tienda: String,
    val ciudad: String,
    val codigo_postal: String,
    val telefono: String,
    val horario: String,
    val propietario_id: Int,
    val imagenes: String = "[]",
    val latitud: Double? = null,
    val longitud: Double? = null
)


data class Producto(
    val id_producto: Int,
    val nombre: String,
    val descripcion: String,
    val peso_kg: Double,
    val imagen_producto: String,
    val tienda_id: Int,
    val disponible: Int,            //1 available 0 not available
    val fecha_caducidad: String? = null
) {
    fun getImagenUrl(): String = "http://10.0.2.2:8000/static/img/$imagen_producto"

    val estaDisponible get() = disponible == 1
}

data class CrearProductoRequest(
    val tienda_id: Int,
    val nombre: String,
    val descripcion: String,
    val imagen_producto: String?,
    val peso_kg: Double,
    val fecha_caducidad: String?,
    val disponible: Int = 1
)

data class EditarProductoRequest(
    val nombre: String?,
    val descripcion: String?,
    val peso_kg: Double?,
    val disponible: Int?,
    val fecha_caducidad: String?
)


data class Pedido(
    val id_salvado: Int,
    val producto_nombre: String,
    val nombre_tienda: String,
    val peso_salvado: Double,
    val estado: String,
    val fecha: String
)

data class PedidoPropietario(
    val id_salvado: Int,
    val producto_nombre: String,
    val imagen_producto: String?,
    val cliente_nombre: String,
    val cliente_telefono: String?,
    val peso_salvado: Double,
    val estado: String,
    val fecha: String
) {
    fun getImagenProductoUrl(): String? =
        imagen_producto?.let { "http://10.0.2.2:8000/static/img/$it" }
}


data class SalvarRequest(val id_usuario: Int, val id_producto: Int, val peso: Int)
data class SalvarResponse(val mensaje: String)


data class Categoria(val id_categoria: Int, val nombre: String)


data class CartItem(val producto: Producto, val cantidad: Int = 1)